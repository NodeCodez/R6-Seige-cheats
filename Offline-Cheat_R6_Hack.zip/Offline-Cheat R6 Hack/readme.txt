Hello Welcome to a Rainbow Six Siege Hack:

Instructions:

Step-one:
Edit your properites in Game luanching for steam and ubisoft
and change startup of the game to = /belaunch -be

to Make sure that Battle Eye is Not running

Step-two:
Play a localGame with friends and claim that you are better than them and have fun

Enjoy, also make sure to check if it is running by starting the batch file called "isbattleyerunning.bat"

And You Should Be Set to Go

Discord:
------------------------------
https://discord.gg/ZjxY2qSf37
------------------------------